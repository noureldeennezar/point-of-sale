import 'package:flutter/material.dart';
import '../classes/MenuItem.dart';
import '../classes/payment.dart';
import '../home.dart';
import '../services/sql_order_helper.dart';

class Checkout extends StatefulWidget {
  final List<Item> orderItems;
  final String title;
  final String name;
  final String loggedInUserName;

  const Checkout({
    super.key,
    required this.orderItems,
    required this.title,
    required this.name,
    required this.loggedInUserName,
  });

  @override
  _CheckoutState createState() => _CheckoutState();
}

class _CheckoutState extends State<Checkout> {
  final TextEditingController _cashController = TextEditingController();
  final TextEditingController _creditCardController = TextEditingController();
  List<Item> orderItems = []; // Items added to the order

  double get totalAmount {
    // Parse the values entered in the cash and credit card fields and sum them.
    double cashAmount = double.tryParse(_cashController.text) ?? 0.0;
    double creditCardAmount =
        double.tryParse(_creditCardController.text) ?? 0.0;
    return cashAmount + creditCardAmount;
  }

  Future<void> checkout() async {
    try {
      if (orderItems.isEmpty) {/*
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No items to checkout')),
        );*/
        return;
      }

      // Define the order number (replace with logic to generate a unique order number)
      int orderNumber = cur + 1;

      // Create an order object
      Order order = Order(
        orderNumber: orderNumber,
        items: orderItems,
      );

      // Insert the order into the database
      DBHelper dbHelper = DBHelper();
      await dbHelper.insertOrder(order);

      // Clear the order after successful checkout
      setState(() {
        cur = orderNumber; // Update current order number
        orderItems.clear();
      });

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Order checked out successfully')),
      );
    } catch (e) {
      print("Error during checkout: $e"); // Log the error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to checkout: $e')),
      ); // Show error message
    }
  }

  void _processPayment() {
    double amount = totalAmount;
    _cashController.text = '0'; // Initialize it to 0
    _creditCardController.text = '0'; // Initialize it to 0

    if (amount > 0) {
      final payment = Payment(
        paymentType: 'Mixed Payment',
        amount: amount,
        isSuccessful: true,
      );

      print("Payment processed: $payment");
      Navigator.pop(context, payment);
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("Enter a valid amount")));
    }
  }

  @override
  Widget build(BuildContext context) {
    double subtotal = widget.orderItems.fold<double>(
        0, (total, item) => total + (item.salesPrice * item.quantity));
    double serviceCharge = subtotal * 0.10;
    double tax = subtotal * 0.10;
    double total = subtotal + serviceCharge + tax;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          title: const Text("CHECK OUT"),
        ),
        body: SingleChildScrollView(
          child: Row(
            children: [
              Expanded(
                flex: 5,
                child: Container(
                  color: Colors.black,
                  child: Center(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: SizedBox(
                                height: 500,
                                child: ListView.builder(
                                  itemCount: widget.orderItems.length,
                                  itemBuilder: (context, index) {
                                    final item = widget.orderItems[index];
                                    return Card(
                                      color: Colors.grey.shade800,
                                      margin: const EdgeInsets.symmetric(
                                          vertical: 4.0),
                                      child: ListTile(
                                        contentPadding:
                                            const EdgeInsets.all(8.0),
                                        title: Text(
                                          item.itemName,
                                          style: const TextStyle(
                                              fontSize: 13,
                                              color: Colors.white),
                                        ),
                                        subtitle: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Quantity: ${item.quantity}',
                                              style: const TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.white),
                                            ),
                                            Text(
                                              '${(item.salesPrice * item.quantity).toStringAsFixed(2)}',
                                              style: const TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.white),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                            const SizedBox(width: 20),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  buildSummaryRow(
                                      'Subtotal:', subtotal.toStringAsFixed(2)),
                                  buildSummaryRow('Service Charge:',
                                      serviceCharge.toStringAsFixed(2)),
                                  buildSummaryRow(
                                      'Tax:', tax.toStringAsFixed(2)),
                                  buildSummaryRow(
                                      'Total:', total.toStringAsFixed(2),
                                      isTotal: true),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 2,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      // Cash Input Field
                      TextField(
                        controller: _cashController,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                          labelText: "Cash",
                          labelStyle: TextStyle(color: Colors.white),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            // Update any logic if needed when the cash value changes
                          });
                        },
                      ),

                      const SizedBox(height: 20),

                      // Credit Card Input Field
                      TextField(
                        controller: _creditCardController,
                        // Different controller for Credit Card
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                          labelText: "Credit Card",
                          labelStyle: TextStyle(color: Colors.white),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white),
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            // Update any logic if needed when the credit card value changes
                          });
                        },
                      ),

                      const SizedBox(height: 20),

                      // Display Total
                      Text(
                        "Total: ${totalAmount.toStringAsFixed(2)}",
                        style:
                            const TextStyle(fontSize: 18, color: Colors.white),
                      ),

                      const SizedBox(height: 20),

                      // Complete Payment Button
                      MaterialButton(
                        onPressed: () {
                          try {
                            checkout();
                          } catch (e) {
                            print('Error during navigation: $e');
                          }
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => MyHomePage(
                                      title: widget.title,
                                      name: widget.name,
                                      loggedInUserName: widget.loggedInUserName)));
                        },
                        child: const Center(
                          child: Text(
                            'Check out',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildSummaryRow(String label, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: isTotal ? Colors.green : Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
